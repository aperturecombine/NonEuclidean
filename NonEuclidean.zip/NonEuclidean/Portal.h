#pragma once
class Portal
{
};

